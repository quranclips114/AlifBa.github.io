
  # Quran Learning Website

  This is a code bundle for Quran Learning Website. The original project is available at https://www.figma.com/design/ULHhtTCX7ERjvY6aROXDvc/Quran-Learning-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  