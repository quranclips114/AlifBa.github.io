# 🔊 Audio Files Setup Guide

## How to Add Your Custom Sound Files

Since I cannot directly receive files through this chat, here's how to add your custom audio files to your local project:

---

## 📁 **Step 1: Prepare Your Audio Files**

Make sure your audio files are:
- ✅ In **MP3 format** (recommended) or WAV/OGG
- ✅ **Named correctly** according to the table below
- ✅ **Good quality** (128kbps or higher recommended)
- ✅ **Small file size** (under 500KB each for fast loading)

---

## 📝 **Step 2: File Naming Reference**

### **Letters (28 files)**

| Arabic | Letter Name | Filename Required |
|--------|-------------|-------------------|
| ا | Alif | `alif.mp3` |
| ب | Ba | `ba.mp3` |
| ت | Ta | `ta.mp3` |
| ث | Tha | `tha.mp3` |
| ج | Jeem | `jeem.mp3` |
| ح | Ha | `ha.mp3` |
| خ | Kha | `kha.mp3` |
| د | Dal | `dal.mp3` |
| ذ | Dhal | `dhal.mp3` |
| ر | Ra | `ra.mp3` |
| ز | Zay | `zay.mp3` |
| س | Seen | `seen.mp3` |
| ش | Sheen | `sheen.mp3` |
| ص | Sad | `sad.mp3` |
| ض | Dad | `dad.mp3` |
| ط | Ta | `ta2.mp3` |
| ظ | Dha | `dha.mp3` |
| ع | Ayn | `ayn.mp3` |
| غ | Ghayn | `ghayn.mp3` |
| ف | Fa | `fa.mp3` |
| ق | Qaf | `qaf.mp3` |
| ك | Kaf | `kaf.mp3` |
| ل | Lam | `lam.mp3` |
| م | Meem | `meem.mp3` |
| ن | Noon | `noon.mp3` |
| ه | Ha | `ha2.mp3` |
| و | Waw | `waw.mp3` |
| ي | Ya | `ya.mp3` |

### **Words (12 files)**

| Arabic | Transliteration | Filename Required |
|--------|-----------------|-------------------|
| الله | Allah | `allah.mp3` |
| الحمد | Al-Hamd | `alhamd.mp3` |
| رب | Rab | `rab.mp3` |
| العالمين | Al-'Aalameen | `aalameen.mp3` |
| الرحمن | Ar-Rahman | `arrahman.mp3` |
| الرحيم | Ar-Raheem | `arraheem.mp3` |
| مالك | Malik | `malik.mp3` |
| يوم | Yawm | `yawm.mp3` |
| الدين | Ad-Deen | `addeen.mp3` |
| إياك | Iyyaka | `iyyaka.mp3` |
| نعبد | Na'budu | `nabudu.mp3` |
| نستعين | Nasta'een | `nastaeen.mp3` |

---

## 📂 **Step 3: Add Files to Your Project**

1. **Locate the `/audio` folder** in your project directory
2. **Copy all your audio files** into the `/audio` folder
3. **Ensure filenames match exactly** (case-sensitive!)
4. **Refresh your browser** after adding files

### Project Structure Should Look Like:
```
your-project/
├── audio/
│   ├── README.md
│   ├── alif.mp3
│   ├── ba.mp3
│   ├── ta.mp3
│   ├── ... (all other letters)
│   ├── allah.mp3
│   ├── alhamd.mp3
│   └── ... (all other words)
├── components/
├── contexts/
└── ...
```

---

## 🎯 **How It Works**

The app uses a **smart priority system**:

1. **🥇 Your local files** - Checks `/audio` folder first
2. **🥈 AlQuran.cloud API** - For Quranic verses (if applicable)
3. **🥉 Browser speech synthesis** - As last resort fallback

### Example Flow:
```
User clicks audio button for "ا"
    ↓
Try: /audio/alif.mp3 ✅ (YOUR FILE PLAYS!)
    ↓ (if not found)
Try: AlQuran.cloud API ❌ (not applicable for letters)
    ↓ (if failed)
Use: Browser text-to-speech 🔊 (robotic voice)
```

---

## ✅ **Testing Your Audio Files**

After adding your files:

1. Open the **Beginner Page** (Learn Letters)
2. Click the audio button 🔊 next to any letter
3. Open browser console (F12) to see logs:
   - ✅ `"Using local audio file: /audio/alif.mp3"` = SUCCESS!
   - ❌ `"Local audio file not found"` = Check filename/location

---

## 🔧 **Troubleshooting**

### Audio not playing?
- ✅ Check filename matches exactly (case-sensitive!)
- ✅ Ensure file is in `/audio` folder
- ✅ Try refreshing browser (Ctrl+F5 / Cmd+Shift+R)
- ✅ Check browser console for errors (F12)
- ✅ Verify file format is MP3, WAV, or OGG

### Wrong audio playing?
- Check you're using the correct filename from tables above
- Ensure no duplicate files with similar names

### File won't load?
- File might be corrupted - try re-exporting
- File might be too large - compress to under 500KB
- Browser might not support format - convert to MP3

---

## 📋 **Quick Checklist**

Before asking for help, verify:
- [ ] All files are in `/audio` folder
- [ ] Filenames match exactly (e.g., `alif.mp3` not `Alif.mp3`)
- [ ] Files are in MP3/WAV/OGG format
- [ ] Browser is refreshed after adding files
- [ ] Console shows no errors (F12)

---

## 🚀 **What's Already Set Up For You**

I've already created:
- ✅ `/audio` folder structure
- ✅ Audio mapping system (`/utils/audioMapping.ts`)
- ✅ Updated AudioButton component with local file support
- ✅ Fallback system for missing files
- ✅ All necessary infrastructure

**You just need to add your MP3 files!** 🎵

---

## 💡 **Need Help?**

If you encounter issues:
1. Check the browser console (F12) for error messages
2. Verify filenames against the tables above
3. Make sure files are actually in the `/audio` folder
4. Try with one file first to test the system

The system is designed to be **plug-and-play** - just drop your files in and it works! 🎉
